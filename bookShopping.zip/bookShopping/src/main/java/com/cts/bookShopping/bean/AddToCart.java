package com.cts.bookShopping.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity(name = "addToCart")
@Table(name = "addToCart")
public class AddToCart {
@Id
@Column(name = "cartId")
private String cartId;
@Column(name = "bookId")
private String bookId;
@Column(name = "userId")
public String userId;
public AddToCart() {
}
@Override
public String toString() {
	return "addToCart [cartId=" + cartId + ", bookId=" + bookId + ", userId=" + userId + "]";
}
public String getCartId() {
	return cartId;
}
public void setCartId(String cartId) {
	this.cartId = cartId;
}
public String getBookId() {
	return bookId;
}
public void setBookId(String bookId) {
	this.bookId = bookId;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public AddToCart(String cartId, String bookId, String userId) {
	super();
	this.cartId = cartId;
	this.bookId = bookId;
	this.userId = userId;
}
}