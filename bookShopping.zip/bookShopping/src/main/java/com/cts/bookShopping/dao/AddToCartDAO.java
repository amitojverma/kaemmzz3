package com.cts.bookShopping.dao;

import com.cts.bookShopping.bean.AddToCart;

public interface AddToCartDAO {
	public String addCartDetails(AddToCart add);
	public AddToCart viewCartDetails(String id); 
}
