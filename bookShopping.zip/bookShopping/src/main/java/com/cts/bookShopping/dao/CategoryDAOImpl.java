package com.cts.bookShopping.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cts.bookShopping.bean.Books;
import com.cts.bookShopping.bean.Category;
@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO{
	@Autowired
	@Qualifier("sessionFactory")
	SessionFactory sessionFactory;

	@Transactional(readOnly=true)
	public List<Category> getCategoryName() {
		Session session = null;
		
	      try {
	    	  String query= "from Category";
	    		Query<Category> query2=null;
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<Category> category = query2.getResultList();
	    				if(category==null)
	    					return null;
	    				else
	    					return category;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
	      
	    			return null;
	}

	@Transactional
	public List<Category> getAllCategory() {
		Session session = null;
		
	      try {
	    	  String query= "from Category";
	    		Query<Category> query2=null;
	    			
	    				session = sessionFactory.getCurrentSession();
	    				query2=session.createQuery(query);
	    				
	    				List<Category> category = query2.getResultList();
	    				if(category==null)
	    					return null;
	    				else
	    					return category;
	    			} catch (Exception e) {
	    				e.printStackTrace();
	    			}
	      
		return null;
	}

	@Transactional
	public String insertCategory(Category cat) {
		/*Session session = null;
		try {
		session = sessionFactory.getCurrentSession();
		//transaction = session.getTransaction();
		//transaction.begin();
		
		session.save(cat);
			return "true";
		}
		catch(Exception e)
		{
		      e.printStackTrace();
		}
		*/
		return "false";
	}
	@Transactional
	public Category viewCategoryByName(String categoryName){
	/*	Session session = null;
		
		String query= "from Category where catName = ?";
	Query<Category> query2=null;
		try {
			session = sessionFactory.getCurrentSession();
			query2=session.createQuery(query);
			query2.setParameter(0, categoryName);
			Category books = query2.getSingleResult();
			if(books==null)
				return null;
			else
				return books;
		} catch (Exception e) {
			e.printStackTrace();
		}*/
		return null;
		
	}

}
