package com.cts.bookShopping.service;

import com.cts.bookShopping.bean.AddToCart;

public interface AddToCartService {
	public String addCartDetails(AddToCart add);
	public AddToCart viewCartDetails(String id); 
}
